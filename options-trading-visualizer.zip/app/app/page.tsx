
import OptionsVisualizer from '@/components/options-visualizer';

export default function Home() {
  return (
    <main>
      <OptionsVisualizer />
    </main>
  );
}
